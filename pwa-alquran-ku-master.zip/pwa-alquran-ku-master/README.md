<h3>Demo site: </h3>
<a href="https://al-quran-ku.web.app">Here</a></h3>
<br><br>


<h5>Dibuat: </h5>
<ul>
	<li>JavaScript</li>
	<li>Materiallize</li>
	<li>CSS</li>
</ul>

<!-- <h5>Splash Screen</h5>
<img src="https://user-images.githubusercontent.com/24710799/102706709-d639c480-42c6-11eb-9613-8cc6d83b30d4.jpg"> -->
<h5>Home/beranda</h5>
<img src="https://user-images.githubusercontent.com/24710799/104562571-1e0bfb80-567b-11eb-9eb7-206392714487.png">
<h5>Surah Tersimpan</h5>
<img src="https://user-images.githubusercontent.com/24710799/104562574-1fd5bf00-567b-11eb-9b21-169794dfb473.png">
<h5>Detail Surah</h5>
<img src="https://user-images.githubusercontent.com/24710799/104562562-1c423800-567b-11eb-9851-17ed0701b038.png">
<img src="https://user-images.githubusercontent.com/24710799/104562567-1d736500-567b-11eb-9b81-80761bd50c80.png">

<hr />
<p>Made from tjimati @2020</p>