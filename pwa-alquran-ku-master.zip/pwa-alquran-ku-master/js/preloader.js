document.getElementById('content').style.display = 'none';
      setTimeout(function(){
        document.getElementById('preloader').style.display = 'none';
        document.getElementById('content').style.display = 'block';
      }, 2000);